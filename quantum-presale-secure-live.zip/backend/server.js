const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const mongoose = require("mongoose");
const crypto = require("crypto");
const app = express();

app.use(cors({ origin: "https://YOUR_FRONTEND_DOMAIN" }));
app.use(bodyParser.json());

const PORT = process.env.PORT || 3000;
const TOKEN_PRICE = 0.02;
const WEBHOOK_SECRET = "YOUR_NOWPAYMENTS_SECRET"; // Webhook imza doğrulama

// MongoDB bağlantısı
mongoose.connect("mongodb://username:password@host:port/quantum_presale?tls=true", { useNewUrlParser: true, useUnifiedTopology: true });

const userSchema = new mongoose.Schema({
    wallet: String,
    totalTokens: Number
});
const User = mongoose.model("User", userSchema);

// Create order endpoint
app.post("/api/create-order", async (req,res)=>{
    const { wallet, usdAmount } = req.body;
    if(!wallet || !usdAmount) return res.status(400).json({error:"Invalid data"});

    let user = await User.findOne({ wallet });
    if(!user){
        user = new User({ wallet, totalTokens: 0 });
        await user.save();
    }

    const paymentLink = `https://nowpayments.io/donation?api_key=DEMO_KEY&amount=${usdAmount}&order_id=${wallet}`;
    res.json({ paymentLink });
});

// Webhook endpoint with signature verification
app.post("/api/webhook/nowpayments", async (req,res)=>{
    const signature = req.headers['x-nowpayments-signature'];
    const hmac = crypto.createHmac('sha512', WEBHOOK_SECRET);
    hmac.update(JSON.stringify(req.body));
    const digest = hmac.digest('hex');

    if(signature !== digest) return res.status(403).send("Invalid signature");

    const { order_id, amount_paid } = req.body;
    if(!order_id || !amount_paid) return res.status(400).send("Invalid data");

    const tokens = amount_paid / TOKEN_PRICE;
    const user = await User.findOne({ wallet: order_id });
    if(user){
        user.totalTokens += tokens;
        await user.save();
    }
    res.sendStatus(200);
});

// Get user tokens
app.get("/api/user-tokens/:wallet", async (req,res)=>{
    const wallet = req.params.wallet;
    const user = await User.findOne({ wallet });
    const totalTokens = user ? user.totalTokens : 0;
    res.json({ totalTokens });
});

app.listen(PORT, ()=>console.log(`Secure Live Server running on port ${PORT}`));