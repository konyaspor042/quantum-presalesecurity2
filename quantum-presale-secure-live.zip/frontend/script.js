const BONUS = 0.25;
const BACKEND_URL = "https://YOUR_SECURE_BACKEND_URL"; // Backend URL

document.getElementById("buyBtn").addEventListener("click", async () => {
    const usd = parseFloat(prompt("Enter the USD amount you want to spend:", "10"));
    if(!usd || usd <= 0 || isNaN(usd)) return alert("Please enter a valid USD amount.");

    let wallet = document.getElementById("walletAddress").value || "default_user";

    // Create order via backend
    const res = await fetch(`${BACKEND_URL}/api/create-order`, {
        method:"POST",
        headers: { "Content-Type":"application/json" },
        body: JSON.stringify({ wallet, usdAmount:usd })
    });
    const data = await res.json();
    if(!data.paymentLink) return alert("Error creating payment.");

    document.getElementById("userPanel").style.display = "block";
    document.getElementById("status").innerText = "Awaiting Payment...";
    document.getElementById("totalToken").innerText = "0";

    window.open(data.paymentLink, "_blank");

    const interval = setInterval(async ()=>{
        const resp = await fetch(`${BACKEND_URL}/api/user-tokens/${wallet}`);
        const userData = await resp.json();
        if(userData.totalTokens > 0){
            const totalWithBonus = userData.totalTokens * (1+BONUS);
            document.getElementById("status").innerText = "Payment Successful!";
            document.getElementById("totalToken").innerText = Math.round(totalWithBonus);
            clearInterval(interval);
        }
    },5000);
});